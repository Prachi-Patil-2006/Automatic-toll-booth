#include <SPI.h>
#include <MFRC522.h>
#include <Servo.h>
#include <LiquidCrystal_I2C.h>

#define SS_PIN 10
#define RST_PIN 9
#define SERVO_PIN 3

MFRC522 rfid(SS_PIN, RST_PIN);
Servo gateServo;
LiquidCrystal_I2C lcd(0x27, 16, 2);

byte authTag[] = {0x53, 0x10, 0xD3, 0x56};

void setup() {
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();

  gateServo.attach(SERVO_PIN);
  gateServo.write(0);

  lcd.init();
  lcd.backlight();
  displayIdle();
}

void loop() {

  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    return;
  }

  bool match = true;

  for (byte i = 0; i < 4; i++) {
    if (rfid.uid.uidByte[i] != authTag[i]) {
      match = false;
      break;
    }
  }

  if (match) {
    accessGranted();
  } else {
    accessDenied();
  }

  rfid.PICC_HaltA();
}

void accessGranted() {

  lcd.clear();
  lcd.print("Access Granted");

  gateServo.write(90);
  delay(3000);

  gateServo.write(0);

  displayIdle();
}

void accessDenied() {

  lcd.clear();
  lcd.print("Access Denied");

  delay(2000);

  displayIdle();
}

void displayIdle() {

  lcd.clear();
  lcd.print("Scan RFID");
}

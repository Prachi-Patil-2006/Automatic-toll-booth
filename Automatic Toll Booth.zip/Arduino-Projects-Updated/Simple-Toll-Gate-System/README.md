# Simple Toll Gate System

Arduino-based automatic toll gate system using Servo Motor and I2C LCD.

## Components
- Arduino UNO/Nano
- Servo Motor
- I2C LCD Display

## Features
- Automatic gate opening
- LCD message display
- Servo-based toll gate mechanism

## Author
Rutuja Shingare

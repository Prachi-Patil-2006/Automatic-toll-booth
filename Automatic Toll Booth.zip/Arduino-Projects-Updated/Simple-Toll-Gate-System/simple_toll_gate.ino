#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Servo.h>

LiquidCrystal_I2C lcd(0x27,16,2);
Servo s;

void setup() {
  lcd.init();
  lcd.backlight();
  s.attach(9);
}

void loop() {

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Toll Open");

  s.write(90);

  delay(3000);

  s.write(0);

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Toll Closed");

  delay(2000);
}
